import { Grid } from "@mui/material";

const InstaImg = ({ imgURL }) => {
  return (
    <>
      <Grid md={4} sm={4}>
        <img src={imgURL} height={300} width={380} />
      </Grid>
    </>
  );
};

export default InstaImg;
