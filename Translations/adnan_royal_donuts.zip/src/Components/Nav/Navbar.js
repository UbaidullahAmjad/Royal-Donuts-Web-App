import React from "react";
import ButtonUnstyled, {
  buttonUnstyledClasses,
} from "@mui/base/ButtonUnstyled";
import { styled } from "@mui/system";
import "../../HomePage/header/header.css";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import { ShoppingCartOutlined, Menu } from "@material-ui/icons";

const Item = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(1),
  textAlign: "center",
}));

const blue = {
  500: "#F36292",
  600: "#C25C7C",
  700: "#C25C7C",
};

const CustomButtonRoot = styled("button")`
  font-family: Bowhead;
  font-size: 32px;
  font-weight: bold;
  background-color: ${blue[500]};
  padding: 7px 24px;
  border-radius: 25px;
  margin-right: 10px;
  color: white;
  transition: all 150ms ease;
  cursor: pointer;
  border: none;

  &:hover {
    background-color: ${blue[600]};
  }

  &.${buttonUnstyledClasses.active} {
    background-color: ${blue[700]};
  }

  &.${buttonUnstyledClasses.focusVisible} {
    box-shadow: 0 4px 20px 0 rgba(61, 71, 82, 0.1),
      0 0 0 5px rgba(0, 127, 255, 0.5);
    outline: none;
  }
`;

function CustomButton(props) {
  return <ButtonUnstyled {...props} component={CustomButtonRoot} />;
}

const NavBar = () => {
  return (
    <div>
      <Grid item xs={12} sm={12} md={12}>
        <div
          id="container"
          //   style={{
          //     display: "flex",
          //     flexDirection: "row",
          //     justifyContent: "center",
          //     position: "absolute",
          //     left: 0,
          //     right: 0,
          //     marginLeft: "auto",
          //     marginRight: "auto",
          //     marginTop: 10,
          //   }}
          style={{
            height: "5rem",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "transparent",
            position: "relative",
            zIndex: 1,
          }}
        >
          <img
            src="/images/royal_donuts_logo.png"
            height={50}
            style={{ width: "15%" }}
            alt=""
            id="logo_image"
          />
          <div style={{ marginLeft: "10%" }}>
            <CustomButton id="products">Our Products</CustomButton>
            <CustomButton id="store">Find a store</CustomButton>
          </div>
          <div
            id="menu"
            style={{
              marginLeft: "1%",
              marginTop: 14,
              display: "flex",
              flexDirection: "row",
            }}
          >
            <a style={{ display: "block" }}>
              <ShoppingCartOutlined style={{ fill: "#fff" }} />
            </a>
            <a style={{ display: "block", marginLeft: 10 }}>
              <Menu style={{ fill: "#fff" }} />
            </a>
          </div>
        </div>
      </Grid>
    </div>
  );
};

export default NavBar;
