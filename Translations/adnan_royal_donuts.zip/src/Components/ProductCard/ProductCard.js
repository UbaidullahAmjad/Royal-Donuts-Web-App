import React from "react";
import "../../HomePage/Products/products.css";
import ButtonUnstyled, {
  buttonUnstyledClasses,
} from "@mui/base/ButtonUnstyled";
import { styled } from "@mui/system";

import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";

const reviewGenerator = () => {
  for (let i = 0; i < 6; i++) {
    <img src="/images/product_star.png" height={15} />;
  }
};

const pink = {
  500: "#F36292",
  600: "#C25C7C",
  700: "#C25C7C",
};

const CustomButtonRoot = styled("button")`
  font-family: Bowhead;
  margin-top: 3%;
  font-size: 32px;
  font-weight: bold;
  background-color: ${pink[500]};
  padding: 4px 20px;
  border-radius: 25px;
  margin-right: 10px;
  color: white;
  transition: all 150ms ease;
  cursor: pointer;
  border: none;

  &:hover {
    background-color: ${pink[600]};
  }

  &.${buttonUnstyledClasses.active} {
    background-color: ${pink[700]};
  }

  &.${buttonUnstyledClasses.focusVisible} {
    box-shadow: 0 4px 20px 0 rgba(61, 71, 82, 0.1),
      0 0 0 5px rgba(0, 127, 255, 0.5);
    outline: none;
  }
`;

function CustomButton(props) {
  return <ButtonUnstyled {...props} component={CustomButtonRoot} />;
}

const ProductCard = (props) => {
  const { newProp, imgURL, name, price } = props;
  return (
    <div style={{ width: 235, display: "block", margin: "auto" }}>
      {newProp ? <CustomButton id="product_tag">New</CustomButton> : null}
      <Card
        sx={{ minWidth: 200 }}
        style={{
          padding: "45px 5px",
          width: "50%",
          background: "#e8e8e8",
          borderRadius: 20,
          marginTop: 20,
        }}
      >
        <CardContent>
          <div style={{ width: "auto" }}>
            <img
              src={imgURL}
              style={{
                height: "8rem",
              }}
            />
          </div>
        </CardContent>
      </Card>
      <div>
        <h1 id="product_name">{name}</h1>
      </div>
      <div style={{ display: "flex", flexDirection: "row" }}>
        <h1 id="product_price">{price}</h1>
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            marginTop: 8,
            marginLeft: 20,
          }}
        >
          {Array.from({ length: 5 }).map((_, index) => (
            <img key={index} src="/images/product_star.png" height={15} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
