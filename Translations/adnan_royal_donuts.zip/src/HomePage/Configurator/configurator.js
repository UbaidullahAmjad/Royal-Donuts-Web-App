import { Container } from "@mui/material";
import React from "react";
import "./configurator.css";

import Grid from "@mui/material/Grid";

const Configurator = () => {
  return (
    <div style={{ marginTop: "5%", background: "#f8b5cb" }}>
      <div>
        <img src="/images/configurator_design_5.png" id="config_img" />
      </div>
      <div>
        <div style={{ display: "flex" }}>
          <Grid item xs={12} md={6}>
            <div id="config_text">
              <h1 id="config">Donut </h1>
              <h1 id="config" style={{ lineHeight: "10px" }}>
                Configurator
              </h1>
            </div>

            <div>
              <img src="/images/design_1.png" id="config_left_side" />
            </div>
          </Grid>
          <Grid item xs={10} md={4} style={{ display: "flex" }}>
            <img src="/images/config_1.png" id="config_image1" />

            <img src="/images/config_2.png" id="config_image2" />
          </Grid>
          <Grid
            xs={2}
            md={2}
            style={{ position: "relative", overflow: "hidden" }}
          >
            <div>
              <img src="/images/design_1.png" id="config_right_side" />
              <img
                src="/images/config_circle.png"
                id="config_right_side_circle"
              />
            </div>
          </Grid>
        </div>
      </div>

      <div class="custom-shape-divider-top-1642772984">
        <svg
          data-name="Layer 1"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 1200 120"
          preserveAspectRatio="none"
        >
          <path
            d="M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A600.21,600.21,0,0,1,0,27.35V120H1200V95.8C1132.19,118.92,1055.71,111.31,985.66,92.83Z"
            class="shape-fill"
          ></path>
        </svg>
      </div>
    </div>
  );
};

export default Configurator;
