import { Grid } from "@mui/material";
import React from "react";
import "./footer.css";
import ButtonUnstyled, {
  buttonUnstyledClasses,
} from "@mui/base/ButtonUnstyled";
import { styled } from "@mui/system";
import FacebookIcon from "@material-ui/icons/Facebook";
import InstagramIcon from "@material-ui/icons/Instagram";
import TwitterIcon from "@material-ui/icons/Twitter";

const blue = {
  500: "#fff",
  600: "#a9a9a9",
  700: "#a9a9a9",
};

const CustomButtonRoot = styled("button")`
  font-family: Bowhead;
  font-size: 32px;
  font-weight: bold;
  background-color: ${blue[500]};
  padding: 5px 18px;
  border-radius: 25px;
  margin-right: 10px;
  color: white;
  transition: all 150ms ease;
  cursor: pointer;
  border: none;
  color: #000;

  &:hover {
    background-color: ${blue[600]};
  }

  &.${buttonUnstyledClasses.active} {
    background-color: ${blue[700]};
  }

  &.${buttonUnstyledClasses.focusVisible} {
    box-shadow: 0 4px 20px 0 rgba(61, 71, 82, 0.1),
      0 0 0 5px rgba(0, 127, 255, 0.5);
    outline: none;
  }
`;

function CustomButton(props) {
  return <ButtonUnstyled {...props} component={CustomButtonRoot} />;
}

const Footer = () => {
  return (
    <div id="footer_main">
      <div style={{ display: "flex" }}>
        <Grid sm={2} md={3}>
          <img
            src="/images/footer-left-design.png"
            id="left_image"
            height={300}
            width={300}
          />
        </Grid>
        <Grid sm={2} md={2} id="grid_section">
          <h1 id="heading">MY Account</h1>
          <p style={{ width: "80%" }} id="text">
            Take advantage of promotion now
          </p>
          <CustomButton>Register Now</CustomButton>
        </Grid>
        <Grid sm={2} md={2} id="grid_section">
          <h1 id="heading">Customer Care</h1>
          <h2 id="text">About</h2>
          <h2 id="text">Franchise</h2>
          <h2 id="text">Impreseum</h2>
        </Grid>
        <Grid sm={2} md={2} id="grid_section">
          <h1 id="heading">Information</h1>
          <h2 id="text">Our Blog</h2>
          <h2 id="text">About Our Store</h2>
          <h2 id="text">Secure Shopping</h2>
          <h2 id="text">Private Policy</h2>
        </Grid>
        <Grid sm={2} md={3} id="grid_section">
          <h3 id="heading">Follow Us</h3>
          <div>
            <FacebookIcon style={{ fontSize: "75", color: "#4267B2" }} />
            <InstagramIcon style={{ fontSize: "75", color: "#833AB4" }} />
            <TwitterIcon style={{ fontSize: "75", color: "#1DA1F2" }} />
          </div>
        </Grid>
      </div>
      <div>
        <Grid md={12}>
          <div>
            <img src="/images/footer_line.png" />
          </div>
          <h1
            style={{
              textAlign: "center",
              color: "#fff",
              fontFamily: "LingLengLang",
            }}
          >
            Copyright © 2022 Hanio. All rights reserved.
          </h1>
        </Grid>
      </div>
    </div>
  );
};

export default Footer;
