import { Grid } from "@mui/material";
import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import InstaImg from "../../Components/InstagramImg/InstaImg";

const Instagram = () => {
  const imgURL = "";
  return (
    <div style={{ display: "flex", position: "relative", overflow: "hidden" }}>
      <InstaImg imgURL="/images/insta_1.png" />
      <InstaImg imgURL="/images/insta_2.png" />
      <InstaImg imgURL="/images/insta_3.png" />
      <InstaImg imgURL="/images/insta_4.png" />
      {/* <Grid md={4} sm={4}>
        <img src="/images/insta_1.png" height={300} width={380} />
      </Grid>
      <Grid md={4} sm={4}>
        <img src="/images/insta_2.png" height={300} width={380} />
      </Grid>
      <Grid md={4} sm={4}>
        <img src="/images/insta_3.png" height={300} width={380} />
      </Grid>
      <Grid md={4} sm={4}>
        <img src="/images/insta_4.png" height={300} width={379} />
      </Grid> */}
    </div>
  );
};

export default Instagram;
