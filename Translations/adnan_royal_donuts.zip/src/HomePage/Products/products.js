import React from "react";
import "./products.css";
import ButtonUnstyled, {
  buttonUnstyledClasses,
} from "@mui/base/ButtonUnstyled";
import { styled } from "@mui/system";
import Paper from "@mui/material/Paper";

import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";

import Slider from "react-slick";
import { Container } from "@mui/material";

import { ArrowForward, ArrowBack } from "@material-ui/icons";

//CARD
import ProductCard from "../../Components/ProductCard/ProductCard";

function SampleNextArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
      className={className}
      style={{ ...style, display: "block", background: "black" }}
      onClick={onClick}
    />
  );
}

function SamplePrevArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
      className={className}
      style={{ ...style, display: "block", background: "black" }}
      onClick={onClick}
    />
  );
}

const settings = {
  dots: true,
  infinite: true,
  speed: 500,
  slidesToShow: 4,
  slidesToScroll: 4,
  nextArrow: <SampleNextArrow />,
  prevArrow: <SamplePrevArrow />,
  variableWidth: true,
};

const pink = {
  500: "#F36292",
  600: "#C25C7C",
  700: "#C25C7C",
};

const CustomButtonRoot = styled("button")`
  font-family: Bowhead;
  margin-top: 3%;
  font-size: 32px;
  font-weight: bold;
  background-color: ${pink[500]};
  padding: 4px 20px;
  border-radius: 25px;
  margin-right: 10px;
  color: white;
  transition: all 150ms ease;
  cursor: pointer;
  border: none;

  &:hover {
    background-color: ${pink[600]};
  }

  &.${buttonUnstyledClasses.active} {
    background-color: ${pink[700]};
  }

  &.${buttonUnstyledClasses.focusVisible} {
    box-shadow: 0 4px 20px 0 rgba(61, 71, 82, 0.1),
      0 0 0 5px rgba(0, 127, 255, 0.5);
    outline: none;
  }
`;

function CustomButton(props) {
  return <ButtonUnstyled {...props} component={CustomButtonRoot} />;
}

const Products = () => {
  return (
    <div>
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "center",
          marginTop: "5%",
        }}
      >
        <img
          src="/images/product_left_design.png"
          alt="product left"
          height={20}
        />
        <h1 id="trending_title">Our Trending</h1>
        <img
          src="/images/product_right_design.png"
          alt="product right"
          height={20}
        />
      </div>
      <div>
        <h1 id="product_title">Products</h1>
      </div>
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "center",
        }}
      >
        <CustomButton id="products">Best</CustomButton>
        <CustomButton id="products">Featured</CustomButton>
        <CustomButton id="products">Fresh</CustomButton>
      </div>
      <Container>
        <div style={{ display: "flex", justifyContent: "center" }}>
          <ArrowBack style={{ marginTop: "13%", marginRight: 10 }} />
          <Slider {...settings}>
            <ProductCard
              newProp={true}
              imgURL={"/images/product_1.png"}
              name={"RASPBERRY KISS"}
              price={"$99.00"}
            />

            <ProductCard
              newProp={false}
              imgURL={"/images/product_2.png"}
              name={"RASPBERRY KISS"}
              price={"$99.00"}
            />

            <ProductCard
              newProp={false}
              imgURL={"/images/product_3.png"}
              name={"RASPBERRY KISS"}
              price={"$99.00"}
            />

            <ProductCard
              newProp={false}
              imgURL={"/images/product_4.png"}
              name={"RASPBERRY KISS"}
              price={"$99.00"}
            />
          </Slider>
          <ArrowForward style={{ marginTop: "13%" }} />
        </div>
      </Container>
    </div>
  );
};

export default Products;
