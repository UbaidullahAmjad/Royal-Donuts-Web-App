import { Container, Grid } from "@mui/material";
import React from "react";
import ButtonUnstyled, {
  buttonUnstyledClasses,
} from "@mui/base/ButtonUnstyled";
import { styled } from "@mui/system";

import "./store.css";

const Store = () => {
  const blue = {
    500: "#F36292",
    600: "#C25C7C",
    700: "#C25C7C",
  };

  const CustomButtonRoot = styled("button")`
    font-family: Bowhead;
    font-size: 32px;
    font-weight: bold;
    background-color: ${blue[500]};
    padding: 5px 24px;
    border-radius: 25px;
    margin-right: 10px;
    color: white;
    transition: all 150ms ease;
    cursor: pointer;
    border: none;

    &:hover {
      background-color: ${blue[600]};
    }

    &.${buttonUnstyledClasses.active} {
      background-color: ${blue[700]};
    }

    &.${buttonUnstyledClasses.focusVisible} {
      box-shadow: 0 4px 20px 0 rgba(61, 71, 82, 0.1),
        0 0 0 5px rgba(0, 127, 255, 0.5);
      outline: none;
    }
  `;

  function CustomButton(props) {
    return <ButtonUnstyled {...props} component={CustomButtonRoot} />;
  }

  return (
    <div>
      <Container style={{ display: "flex" }}>
        <Grid sm={12} md={12}>
          <div>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "center",
              }}
            >
              <img
                src="/images/product_left_design.png"
                alt="product left"
                height={20}
              />
              <h1 id="store_title">About Our</h1>
              <img
                src="/images/product_right_design.png"
                alt="product right"
                height={20}
              />
            </div>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "center",
                marginTop: "5%",
              }}
            >
              <h1 id="store_text">STORE!</h1>
            </div>
          </div>
        </Grid>
      </Container>
      <Container style={{ display: "flex" }}>
        <Grid sm={6} md={6}>
          <div>
            <img
              src="/images/store.png"
              alt="store"
              height={300}
              id="store_img"
            />
          </div>
        </Grid>

        <Grid sm={6} md={6} style={{ marginTop: "-6rem" }}>
          <div id="store_desc_title">
            <h1 id="desc_title_text" style={{ lineHeight: "36px" }}>
              Royal
            </h1>
            <h1 id="desc_title_text" style={{ fontSize: 90 }}>
              Locator Store
            </h1>
          </div>
          <div>
            <p style={{ width: 350, paddingLeft: 10, paddingRight: 10 }}>
              More than 90 stores all over Europe. In the store locator, you can
              see all opening hours and addresses at a glance.
            </p>
          </div>
          <div>
            <CustomButton id="store">Find Shop</CustomButton>
          </div>
          <div></div>
        </Grid>
      </Container>
    </div>
  );
};

export default Store;
