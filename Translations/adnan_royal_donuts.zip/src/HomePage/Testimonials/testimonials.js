import { Card, CardContent, Container, Grid } from "@mui/material";
import React from "react";
import Slider from "react-slick";
import "./testimonials.css";

import { ArrowForward, ArrowBack } from "@material-ui/icons";
import { Col, Row } from "react-bootstrap";

const settings = {
  dots: true,
  infinite: true,
  speed: 500,
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
};

const Testimonials = () => {
  const slider = React.useRef(null);

  return (
    <div style={{ marginTop: "5%", background: "#f8b5cb", overflow: "hidden" }}>
      <div class="testimonails-custom-shape-divider-top-1642772984">
        <svg
          data-name="Layer 1"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 1200 120"
          preserveAspectRatio="none"
        >
          <path
            d="M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A600.21,600.21,0,0,1,0,27.35V120H1200V95.8C1132.19,118.92,1055.71,111.31,985.66,92.83Z"
            class="shape-fill"
          ></path>
        </svg>
      </div>
      <div style={{ display: "flex", paddingBottom: 30 }}>
        <Grid sm={10} md={11}>
          <div style={{ display: "block" }}>
            <Slider ref={slider} {...settings}>
              <div>
                <Card
                  style={{
                    marginLeft: 70,
                    background: "transparent",
                    boxShadow: "none",
                  }}
                >
                  <CardContent>
                    <Container fluid>
                      <Row
                        style={{ display: "flex", justifyContent: "center" }}
                      >
                        <Col sm={6} md={6} style={{ marginTop: 55 }}>
                          <Row style={{ display: "flex" }}>
                            <ArrowBack
                              style={{ alignSelf: "center", marginLeft: 200 }}
                              onClick={() => slider?.current?.slickPrev()}
                            />
                            <Col style={{ marginLeft: 100, marginTop: "10%" }}>
                              <h1
                                style={{
                                  fontFamily: "Bowhead",
                                  fontSize: 70,
                                  margin: 0,
                                  lineHeight: "10px",
                                }}
                              >
                                Customers
                              </h1>
                              <h1
                                style={{
                                  fontFamily: "LingLengLang",
                                  fontSize: 70,
                                  marginTop: 0,
                                }}
                              >
                                TESTIMONIALS
                              </h1>
                            </Col>
                          </Row>
                        </Col>
                        <Col sm={6} md={6} style={{ marginLeft: 40 }}>
                          <Row style={{ display: "flex" }}>
                            <Col>
                              <img
                                src="/images/testimonails_donut.png"
                                alt="testimonials donut"
                                style={{
                                  width: 80,
                                  height: 80,
                                  borderRadius: "50%",
                                }}
                              />
                              <div style={{ marginLeft: 20 }}>
                                <h1
                                  style={{
                                    fontFamily: "LingLengLang",
                                    marginBottom: 0,
                                    marginTop: 5,
                                    fontSize: 40,
                                  }}
                                >
                                  Name
                                </h1>
                                <h1
                                  style={{ fontFamily: "Bowhead", margin: 0 }}
                                >
                                  Designer
                                </h1>
                                <p>
                                  Lorem ipsum dolor sit amet conse ctetur
                                  adipisicing elit, sed do eiusmod tempor
                                  incididunt ut labore et dolore magna aliqua.
                                  Ut enim ad minim veniam. Lorem ipsum dolor sit
                                  amet conse ctetur adipisicing elit.
                                </p>
                              </div>
                            </Col>
                            <Col style={{ display: "flex", marginLeft: 50 }}>
                              <ArrowForward
                                style={{ alignSelf: "center", marginTop: 38 }}
                                onClick={() => slider?.current?.slickNext()}
                              />
                            </Col>
                          </Row>
                        </Col>
                      </Row>
                    </Container>
                  </CardContent>
                </Card>
              </div>
              <div>
                <Card
                  style={{
                    marginLeft: 70,
                    background: "transparent",
                    boxShadow: "none",
                  }}
                >
                  <CardContent>
                    <Container fluid>
                      <Row
                        style={{ display: "flex", justifyContent: "center" }}
                      >
                        <Col sm={6} md={6} style={{ marginTop: 55 }}>
                          <Row style={{ display: "flex" }}>
                            <ArrowBack
                              style={{ alignSelf: "center", marginLeft: 200 }}
                              onClick={() => slider?.current?.slickPrev()}
                            />
                            <Col style={{ marginLeft: 100, marginTop: "10%" }}>
                              <h1
                                style={{
                                  fontFamily: "Bowhead",
                                  fontSize: 70,
                                  margin: 0,
                                  lineHeight: "10px",
                                }}
                              >
                                Customers
                              </h1>
                              <h1
                                style={{
                                  fontFamily: "LingLengLang",
                                  fontSize: 70,
                                  marginTop: 0,
                                }}
                              >
                                TESTIMONIALS
                              </h1>
                            </Col>
                          </Row>
                        </Col>
                        <Col sm={6} md={6} style={{ marginLeft: 40 }}>
                          <Row style={{ display: "flex" }}>
                            <Col>
                              <img
                                src="/images/testimonails_donut.png"
                                alt="testimonials donut"
                                style={{
                                  width: 80,
                                  height: 80,
                                  borderRadius: "50%",
                                }}
                              />
                              <div style={{ marginLeft: 20 }}>
                                <h1
                                  style={{
                                    fontFamily: "LingLengLang",
                                    marginBottom: 0,
                                    marginTop: 5,
                                    fontSize: 40,
                                  }}
                                >
                                  Name
                                </h1>
                                <h1
                                  style={{ fontFamily: "Bowhead", margin: 0 }}
                                >
                                  Designer
                                </h1>
                                <p>
                                  Lorem ipsum dolor sit amet conse ctetur
                                  adipisicing elit, sed do eiusmod tempor
                                  incididunt ut labore et dolore magna aliqua.
                                  Ut enim ad minim veniam. Lorem ipsum dolor sit
                                  amet conse ctetur adipisicing elit.
                                </p>
                              </div>
                            </Col>
                            <Col style={{ display: "flex", marginLeft: 50 }}>
                              <ArrowForward
                                style={{ alignSelf: "center", marginTop: 38 }}
                                onClick={() => slider?.current?.slickNext()}
                              />
                            </Col>
                          </Row>
                        </Col>
                      </Row>
                    </Container>
                  </CardContent>
                </Card>
              </div>
            </Slider>
          </div>
        </Grid>
        <Grid sm={2} md={1}>
          <div style={{ justifyContent: "end", display: "flex" }}>
            <img
              src="/images/testimonails_donut.png"
              alt="testimonials donut"
              id="test_donut_img"
            />
          </div>
        </Grid>
      </div>
    </div>
  );
};

export default Testimonials;
