import React from "react";
import ButtonUnstyled, {
  buttonUnstyledClasses,
} from "@mui/base/ButtonUnstyled";
import { styled } from "@mui/system";
import "./header.css";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import { Col, Row } from "react-bootstrap";
import { Container } from "@mui/material";
import { ShoppingCartOutlined, Menu } from "@material-ui/icons";
import NavBar from "../../Components/Nav/Navbar";

const Item = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(1),
  textAlign: "center",
}));

const blue = {
  500: "#F36292",
  600: "#C25C7C",
  700: "#C25C7C",
};

const CustomButtonRoot = styled("button")`
  font-family: Bowhead;
  font-size: 32px;
  font-weight: bold;
  background-color: ${blue[500]};
  padding: 7px 24px;
  border-radius: 25px;
  margin-right: 10px;
  color: white;
  transition: all 150ms ease;
  cursor: pointer;
  border: none;

  &:hover {
    background-color: ${blue[600]};
  }

  &.${buttonUnstyledClasses.active} {
    background-color: ${blue[700]};
  }

  &.${buttonUnstyledClasses.focusVisible} {
    box-shadow: 0 4px 20px 0 rgba(61, 71, 82, 0.1),
      0 0 0 5px rgba(0, 127, 255, 0.5);
    outline: none;
  }
`;

function CustomButton(props) {
  return <ButtonUnstyled {...props} component={CustomButtonRoot} />;
}

const Header = () => {
  return (
    <div>
      <header
        style={{
          backgroundColor: "#f8b5cb",
          paddingTop: 15,
          overflow: "hidden",
        }}
      >
        <NavBar />
        <div>
          <Grid container>
            <Grid item xs={12} md={12}>
              <Container>
                <img
                  src="/images/flow_1.png"
                  alt="flow 1"
                  height={350}
                  id="flow_right_image"
                />
              </Container>
              <div style={{ display: "flex", height: "26rem" }}>
                <Grid item xs={4} md={3}>
                  <img
                    src="/images/header_left_donut.png"
                    alt="left donut"
                    style={{
                      marginLeft: "-10%",
                      position: "absolute",
                      height: "39rem",
                      zIndex: 10,
                    }}
                  />
                  <img
                    src="/images/design_2.png"
                    alt="design 2"
                    style={{ marginLeft: "-40rem", marginTop: "60%" }}
                  />
                </Grid>
                <Grid item xs={4} md={5}>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "end",
                    }}
                  >
                    <img
                      src="/images/title_design_left.png"
                      height={30}
                      alt="title left"
                    />
                    <h1 id="head_title">Discover about incredible</h1>
                    <img
                      src="/images/title_design_right.png"
                      height={30}
                      alt="title right"
                    />
                  </div>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "center",
                    }}
                  >
                    <h1 id="head_title_2">VARIETY</h1>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "center",
                    }}
                  >
                    <p
                      style={{
                        width: "70%",
                        marginTop: "4%",
                        marginLeft: "25%",
                      }}
                    >
                      From standard to vegan, from cross donuts to XXL party,
                      cakes, or just let off steam in the innovative
                      Royal-Cretoria
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "center",
                    }}
                  >
                    <CustomButton id="shop_now">Shop Now</CustomButton>
                  </div>
                </Grid>
                <Grid item xs={4} md={4}>
                  <div>
                    <img
                      src="/images/header_right_donut.png"
                      id="header_right_donut"
                    />
                    <img
                      src="/images/design_3.png"
                      alt="design 3"
                      style={{ height: "30rem", marginLeft: "12%" }}
                    />
                  </div>
                </Grid>
              </div>
            </Grid>
          </Grid>
        </div>
        <div className="custom-shape-divider-bottom-1642677977">
          <svg
            data-name="Layer 1"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 1200 120"
            preserveAspectRatio="none"
          >
            <path
              d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z"
              className="shape-fill"
            ></path>
          </svg>
        </div>
      </header>
    </div>
  );
};

export default Header;
