import React from "react";
import Header from "./header/header";
import Products from "./Products/products";
import Configurator from "./Configurator/configurator";
import Store from "./Store/store";
import Testimonials from "./Testimonials/testimonials";
import Instagram from "./Instagram/instagram";
import Footer from "./Footer/footer";

const Main = () => {
  return (
    <>
      <Header />
      <Products />
      <Configurator />
      <Store />
      <Testimonials />
      <Instagram />
      <Footer />
    </>
  );
};

export default Main;
