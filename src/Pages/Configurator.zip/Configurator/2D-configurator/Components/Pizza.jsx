import simpleDonut from '../images/simpleDonut.png'


const Pizza = ({ selectedGlaze,
    tempArray,
    selectedSauce,
    selectedFilling

}) => {
    return (
        <div className='pizza-container'>
            <img className='donut' src = {simpleDonut} alt='alt'/>
            {selectedGlaze.length >0  &&
                <img className='layers' src = {selectedGlaze[0].image} alt='alt'/>
            }
            {
                selectedSauce.length > 0 && 
                <img className='topp' src = {selectedSauce[0].image} alt='alt'/>
            }
            {
                tempArray.length> 0 &&
                tempArray.map((item,i)=>{
                   if(i == 0)
                   {
                    return   <img className='topp' src = {item.image1} alt='alt'/>
                   }
                   if(i==1)
                   {
                    return   <img className='topp' src = {item.image2} alt='alt'/>
                   }
                   if(i==2)
                   {
                    return   <img className='topp' src = {item.image3} alt='alt'/>
                   }
                   
                })
             
            }
           
            {
                selectedFilling.length >0 &&
                <img className='sauce' src = {selectedFilling[0].image} alt='alt'/>
            }

            {/* {selectedToppings.map(topping =>
                    <PizzaTopping key={topping} topping={topping} toppingAmount={toppingOptions[topping].amount} />)} */}
        </div>
    );
}

export default Pizza