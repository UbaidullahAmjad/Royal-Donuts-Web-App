/** ********************* Glazes ******************* */
import glaze_dark from '../images/glazes/glaze_dark.webp'
import glaze_brown from '../images/glazes/glaze_brown.webp'
import icon_powderzucker from '../images/glazes/icon_puderzucker.webp'
import icon_raspberry from '../images/glazes/icon_raspberry.webp'
import brownLayer from '../images/glazes/brownLayer.webp'
import raspberry_layer from '../images/glazes/raspberry_layer.webp'
import puderzucker_layer from '../images/glazes/puderzuker_layer.webp'
import chocLayer from '../images/glazes/chocLayer.webp'
// *************************************************


/** ******************** Toppings ****************** */
import icon_cornflakes from '../images/toppings/icon_cornflakes.webp'
import icon_waffeln from '../images/toppings/icon_waffeln.webp'
import after_eight from '../images/toppings/topping_aftereight.webp'
import khopra_topping from '../images/toppings/topping_khopra.webp'
import after_eight1 from '../images/toppings/creamTop.png'
import topping_khopra1 from '../images/toppings/topping_khopra1.webp'
import topping_khopra2 from '../images/toppings/topping_khopra2.webp'
import topping_khopra3 from '../images/toppings/topping_khopra3.webp'
import top_biscut from '../images/toppings/top_biscut.webp'
import after_eight2 from '../images/toppings/topping_after_eight2.webp'
import after_eight3 from '../images/toppings/topping_after_eight3.webp'
import topping_waffeln2 from '../images/toppings/topping_waffeln2.webp'
import topping_waffeln3 from '../images/toppings/topping_waffeln3.webp'
import topping_cornflakes1 from '../images/toppings/topping_cornflakes1.webp'
import topping_cornflakes2 from '../images/toppings/topping_cornflakes2.webp'
import topping_cornflakes3 from '../images/toppings/topping_cornflakes3.webp'
// ************************************************


/** ******************** Sauces ******************** */
import icon_peanut_butter from '../images/sauces/icon_peanut_butter.webp'
import darkChocolate from '../images/sauces/darkChocolate.png'
import icon_strawberry from '../images/sauces/icon_strawberry.webp'
import no_sauce from '../images/sauces/no_sauce.webp'
import sauce_darkCh from '../images/sauces/sauce_darkCh.webp'
import sauce_peanut_butter from '../images/sauces/sauce_peanut_butter.png'
import sauce_strawberry from '../images/sauces/sauce_strawberry.png'
// *************************************************


/** ****************** Fillings ******************** */
import blueberry_filling from '../images/fillings/Filling_blueberry.webp'
import filling_Apple from '../images/fillings/fillingApple.webp'
import icon_blueberry_filling from '../images/fillings/icon_blueberryFilling.webp'
import no_filling from '../images/fillings/no_filling.webp'
import appleSauce from '../images/fillings/appleSauce.webp'
import icon_strawberry_filling from '../images/fillings/icon_strawberry_filling.webp'
import strawberry_filling from '../images/fillings/strawberry_filling.webp'
// *************************************************



export const Toppings = {
    glazes: [
        {
            name: 'chocolate (dark)',
            image: chocLayer,
            price: 0.50,
            logo: glaze_dark
        },
        {
            name: 'peanut glaze',
            image: brownLayer,
            price: 0.50,
            logo: glaze_brown
        },
        {
            name: 'raspberry',
            image: raspberry_layer,
            price: 0.50,
            logo: icon_raspberry
        },
        {
            name: 'powdered sugar',
            image: puderzucker_layer,
            price: 0.50,
            logo: icon_powderzucker
        },
        
    ],
    topping:[
        {
            name: 'after eight',
            image1: after_eight1,
            image2: after_eight2,
            image3: after_eight3,
            price:  0.50,
            logo: after_eight
        },
        {
            name: 'desiccated coconut (vegan)',
            image1: topping_khopra1,
            image2: topping_khopra2,
            image3: topping_khopra3,
            price:  0.50,
            logo: khopra_topping
        },
        {
            name: 'waffeln',
            image1: top_biscut,
            image2: topping_waffeln2,
            image3: topping_waffeln3,
            price:  0.50,
            logo: icon_waffeln
        },
        {
            name: 'cornflakes',
            image1: topping_cornflakes1,
            image2: topping_cornflakes2,
            image3: topping_cornflakes3,
            price:  0.50,
            logo: icon_cornflakes
        }
    ],
    sauces :[
        {
            name: 'dark chocolate',
            image: darkChocolate,
            price: 0.5,
            logo: sauce_darkCh
        },
        {
            name: 'peanut butter',
            image: sauce_peanut_butter,
            price: 0.5,
            logo: icon_peanut_butter
        },
        {
            name: 'strawberry',
            image: sauce_strawberry,
            price: 0.5,
            logo: icon_strawberry
        },
      
    ],
    fillings :[
        {
            name: 'applesauce',
            image: appleSauce,
            price: 0.5,
            logo: filling_Apple
        },
        {
            name: 'strawberry',
            image: strawberry_filling,
            price: 0.5,
            logo: icon_strawberry_filling
        },
        {
            name: 'blueberry',
            image: blueberry_filling,
            price: 0.5,
            logo: icon_blueberry_filling
        },
    ]
    
}