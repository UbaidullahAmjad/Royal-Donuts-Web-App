import React from "react";

const slider = (props) => {
  console.log("PROPSSS", props);
  return (
    <div>
      <img
       src = {`https://ecco.royaldonuts.xyz/storage/${props.user_image}`}
        style={{
          width: 80,
          height: 80,
          borderRadius: "50%",
        }}
        alt=""
      />
      <div id="testimonial_content">
        <h1
          style={{
            fontFamily: "LingLengLang",
            marginBottom: 0,
            marginTop: 5,
            fontSize: 40,
          }}
        >
          {props.name != null && props.name}
        </h1>
        {/* <h1
          style={{
            fontFamily: "Bowhead",
            margin: 0,
            lineHeight: "24px",
            marginBottom: 10,
          }}
        >
          le créateur
        </h1> */}
        <p style={{ textAlign: "justify" }} dangerouslySetInnerHTML={{__html: props.description}}>
          {/* {props.description != null && props.description} */}
        </p>
      </div>
    </div>
  );
};

export default slider;
